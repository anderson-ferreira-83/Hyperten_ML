"""
MELHORIAS CRÍTICAS - NOTEBOOK 04: MODEL TRAINING
=================================================

Este arquivo contém todas as implementações prioritárias para o Notebook 04.
Substitua seções específicas do notebook existente por estes códigos.

PRIORIDADE: CRÍTICA
TEMPO ESTIMADO: 8-10 horas
IMPACTO: Corrige problemas metodológicos fundamentais

"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, StratifiedKFold, GridSearchCV
from sklearn.metrics import (confusion_matrix, classification_report, 
                               recall_score, precision_score, f1_score, 
                               fbeta_score, roc_auc_score, roc_curve, make_scorer)
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from imblearn.over_sampling import SMOTE
from sklearn.base import clone
import matplotlib.pyplot as plt
import seaborn as sns
import time

# ============================================================================
# CONFIGURAÇÃO 1: DEFINIR F2-SCORE COMO SCORER PRINCIPAL
# ============================================================================

# Criar scorer personalizado para F2
f2_scorer = make_scorer(fbeta_score, beta=2)

print("="*80)
print("CONFIGURAÇÃO DE MÉTRICAS CLÍNICAS")
print("="*80)
print("\n📊 Hierarquia de Métricas:")
print("   1. F2-Score (beta=2) - MÉTRICA PRINCIPAL para otimização")
print("      Prioriza Recall (detecção de casos de risco)")
print("   2. Recall (Sensibilidade) - REQUISITO MÍNIMO ≥ 90%")
print("   3. Especificidade - Controle de falsos positivos")
print("   4. ROC-AUC - Capacidade discriminatória")
print("="*80)


# ============================================================================
# FUNÇÃO 1: TESTE DE MÚLTIPLAS PROPORÇÕES
# ============================================================================

def testar_proporcoes_treinoteste(X, y, proporcoes=[0.20, 0.25, 0.30], 
                                   modelo=None, random_state=42):
    """
    Testa múltiplas proporções treino/teste para identificar a melhor.
    SMOTE é aplicado corretamente em cada teste.
    
    Parameters:
    -----------
    X : DataFrame
        Features
    y : Series
        Target
    proporcoes : list
        Lista de test_sizes a testar
    modelo : sklearn model, optional
        Modelo a usar (default: RandomForestClassifier)
    random_state : int
        Seed para reprodutibilidade
        
    Returns:
    --------
    tuple
        (melhor_test_size, DataFrame com resultados)
    """
    if modelo is None:
        modelo = RandomForestClassifier(
            n_estimators=100, 
            random_state=random_state,
            class_weight='balanced',
            n_jobs=-1
        )
    
    resultados = []
    
    print("="*80)
    print("TESTE DE MÚLTIPLAS PROPORÇÕES TREINO/TESTE")
    print("="*80)
    
    for test_size in proporcoes:
        print(f"\n📊 Testando proporção {int((1-test_size)*100)}/{int(test_size*100)}...")
        
        # Divisão estratificada
        X_tr, X_te, y_tr, y_te = train_test_split(
            X, y,
            test_size=test_size,
            random_state=random_state,
            stratify=y  # CRÍTICO: Manter proporções
        )
        
        # SMOTE no treino
        smote = SMOTE(random_state=random_state)
        X_tr_bal, y_tr_bal = smote.fit_resample(X_tr, y_tr)
        
        # Treinar modelo
        modelo_temp = clone(modelo)
        modelo_temp.fit(X_tr_bal, y_tr_bal)
        
        # Avaliar
        y_pred = modelo_temp.predict(X_te)
        
        # Métricas
        recall = recall_score(y_te, y_pred)
        f2 = fbeta_score(y_te, y_pred, beta=2)
        fn = sum((y_te == 1) & (y_pred == 0))
        fp = sum((y_te == 0) & (y_pred == 1))
        
        resultados.append({
            'proporcao': f"{int((1-test_size)*100)}/{int(test_size*100)}",
            'test_size': test_size,
            'n_treino': len(X_tr),
            'n_teste': len(X_te),
            'recall': recall,
            'f2_score': f2,
            'falsos_negativos': fn,
            'falsos_positivos': fp
        })
        
        print(f"   Recall: {recall:.4f} | F2: {f2:.4f} | FN: {fn} | FP: {fp}")
    
    # Criar DataFrame e ordenar por F2-Score
    df_prop = pd.DataFrame(resultados)
    df_prop = df_prop.sort_values('f2_score', ascending=False)
    
    print("\n" + "="*80)
    print("RESUMO COMPARATIVO")
    print("="*80)
    print(df_prop.to_string(index=False))
    print("="*80)
    
    melhor = df_prop.iloc[0]
    print(f"\n🎯 MELHOR PROPORÇÃO: {melhor['proporcao']}")
    print(f"   F2-Score: {melhor['f2_score']:.4f}")
    print(f"   Recall: {melhor['recall']:.4f}")
    print(f"   Falsos Negativos: {int(melhor['falsos_negativos'])}")
    
    return melhor['test_size'], df_prop


# ============================================================================
# FUNÇÃO 2: AVALIAÇÃO COMPLETA DE MODELO
# ============================================================================

def avaliar_modelo_completo(modelo, X_train, y_train, X_test, y_test, 
                              nome_modelo="Modelo"):
    """
    Avaliação completa com todas as métricas clínicas relevantes.
    Foco em F2-Score e contexto clínico.
    
    Parameters:
    -----------
    modelo : sklearn model
        Modelo já treinado
    X_train, y_train : array-like
        Dados de treino (para referência)
    X_test, y_test : array-like
        Dados de teste
    nome_modelo : str
        Nome do modelo para identificação
        
    Returns:
    --------
    dict
        Dicionário com todas as métricas
    """
    # Predições
    y_pred = modelo.predict(X_test)
    y_proba = modelo.predict_proba(X_test)[:, 1]
    
    # Matriz de confusão
    tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()
    
    # Calcular todas as métricas
    recall = recall_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred)
    f2 = fbeta_score(y_test, y_pred, beta=2)
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
    roc_auc = roc_auc_score(y_test, y_proba)
    
    # VPP e VPN
    vpp = tp / (tp + fp) if (tp + fp) > 0 else 0
    vpn = tn / (tn + fn) if (tn + fn) > 0 else 0
    
    # Acurácia
    accuracy = (tp + tn) / (tp + tn + fp + fn)
    
    # Estruturar resultados
    resultados = {
        'modelo': nome_modelo,
        'f2_score': f2,
        'recall': recall,
        'specificity': specificity,
        'precision': precision,
        'f1_score': f1,
        'roc_auc': roc_auc,
        'accuracy': accuracy,
        'vpp': vpp,
        'vpn': vpn,
        'fn': fn,
        'fp': fp,
        'tp': tp,
        'tn': tn,
        'atende_recall_90': recall >= 0.90,
        'atende_f2_85': f2 >= 0.85
    }
    
    # Imprimir resultados formatados
    print(f"\n{'='*80}")
    print(f"AVALIAÇÃO: {nome_modelo}")
    print('='*80)
    
    print(f"\n🎯 MÉTRICA PRINCIPAL:")
    marca_f2 = '✓' if f2 >= 0.85 else '✗'
    print(f"   F2-Score: {f2:.4f} {marca_f2} (meta: ≥ 0.85)")
    
    print(f"\n📊 MÉTRICAS CLÍNICAS:")
    marca_recall = '✓' if recall >= 0.90 else '✗'
    print(f"   Recall (Sensibilidade): {recall:.4f} {marca_recall} (requisito: ≥ 0.90)")
    print(f"   Especificidade:         {specificity:.4f}")
    print(f"   Precisão (VPP):         {precision:.4f}")
    print(f"   VPN:                    {vpn:.4f}")
    print(f"   ROC-AUC:                {roc_auc:.4f}")
    
    print(f"\n📈 OUTRAS MÉTRICAS:")
    print(f"   F1-Score:               {f1:.4f}")
    print(f"   Acurácia:               {accuracy:.4f}")
    
    print(f"\n📋 MATRIZ DE CONFUSÃO:")
    print(f"              Predito Negativo  Predito Positivo")
    print(f"   Real Neg:      {tn:6d}            {fp:6d}")
    print(f"   Real Pos:      {fn:6d}            {tp:6d}")
    
    print(f"\n❌ ANÁLISE DE ERROS:")
    print(f"   Falsos Negativos (FN): {fn}")
    print(f"      → Casos de risco NÃO detectados")
    print(f"      → {(fn/(fn+tp)*100):.1f}% dos casos positivos reais")
    print(f"   Falsos Positivos (FP): {fp}")
    print(f"      → Falsos alarmes")
    print(f"      → {(fp/(fp+tn)*100):.1f}% dos casos negativos reais")
    
    print(f"\n{'='*80}")
    
    return resultados


# ============================================================================
# FUNÇÃO 3: CROSS-VALIDATION COM SMOTE CORRETO
# ============================================================================

def cross_validation_com_smote(modelo, X, y, n_splits=5, random_state=42):
    """
    Stratified K-Fold Cross-Validation com SMOTE aplicado corretamente
    em cada fold (evita data leakage).
    
    Parameters:
    -----------
    modelo : sklearn model
        Modelo a ser validado
    X : DataFrame
        Features
    y : Series
        Target
    n_splits : int
        Número de folds
    random_state : int
        Seed para reprodutibilidade
        
    Returns:
    --------
    tuple
        (DataFrame com resultados por fold, dict com estatísticas)
    """
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, 
                          random_state=random_state)
    
    resultados_folds = []
    
    print(f"\n{'='*80}")
    print(f"STRATIFIED {n_splits}-FOLD CROSS-VALIDATION COM SMOTE")
    print('='*80)
    print(f"\n⚠ IMPORTANTE: SMOTE aplicado em cada fold separadamente")
    print(f"              para evitar data leakage\n")
    
    for fold, (train_idx, test_idx) in enumerate(skf.split(X, y), 1):
        print(f"📊 Fold {fold}/{n_splits}...", end=" ")
        
        # Dividir fold
        if isinstance(X, pd.DataFrame):
            X_fold_train, X_fold_test = X.iloc[train_idx], X.iloc[test_idx]
        else:
            X_fold_train, X_fold_test = X[train_idx], X[test_idx]
            
        if isinstance(y, pd.Series):
            y_fold_train, y_fold_test = y.iloc[train_idx], y.iloc[test_idx]
        else:
            y_fold_train, y_fold_test = y[train_idx], y[test_idx]
        
        # Aplicar SMOTE no fold de treino
        smote = SMOTE(random_state=random_state)
        X_fold_train_bal, y_fold_train_bal = smote.fit_resample(
            X_fold_train, y_fold_train
        )
        
        # Treinar modelo clonado
        modelo_fold = clone(modelo)
        modelo_fold.fit(X_fold_train_bal, y_fold_train_bal)
        
        # Avaliar
        y_pred = modelo_fold.predict(X_fold_test)
        y_proba = modelo_fold.predict_proba(X_fold_test)[:, 1]
        
        # Calcular métricas
        tn, fp, fn, tp = confusion_matrix(y_fold_test, y_pred).ravel()
        
        recall = recall_score(y_fold_test, y_pred)
        precision = precision_score(y_fold_test, y_pred, zero_division=0)
        f1 = f1_score(y_fold_test, y_pred)
        f2 = fbeta_score(y_fold_test, y_pred, beta=2)
        specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
        roc_auc = roc_auc_score(y_fold_test, y_proba)
        
        resultados_folds.append({
            'fold': fold,
            'recall': recall,
            'f2_score': f2,
            'f1_score': f1,
            'precision': precision,
            'specificity': specificity,
            'roc_auc': roc_auc,
            'fn': fn,
            'fp': fp
        })
        
        print(f"Recall: {recall:.4f}, F2: {f2:.4f}, FN: {fn}")
    
    # Consolidar resultados
    df_folds = pd.DataFrame(resultados_folds)
    
    # Calcular estatísticas
    print(f"\n{'='*80}")
    print("RESULTADOS CONSOLIDADOS")
    print('='*80)
    
    print(f"\nResultados por fold:")
    print(df_folds[['fold', 'recall', 'f2_score', 'fn', 'fp']].to_string(index=False))
    
    print(f"\n{'='*80}")
    print("ESTATÍSTICAS (Média ± Desvio Padrão)")
    print('='*80)
    
    metricas = ['recall', 'f2_score', 'f1_score', 'specificity', 'roc_auc']
    estatisticas = {}
    
    for metrica in metricas:
        mean = df_folds[metrica].mean()
        std = df_folds[metrica].std()
        min_val = df_folds[metrica].min()
        max_val = df_folds[metrica].max()
        
        estatisticas[metrica] = {
            'media': mean,
            'std': std,
            'min': min_val,
            'max': max_val
        }
        
        print(f"\n{metrica.upper()}:")
        print(f"   {mean:.4f} ± {std:.4f}")
        print(f"   Range: [{min_val:.4f}, {max_val:.4f}]")
    
    # Estatísticas de FN
    fn_mean = df_folds['fn'].mean()
    fn_std = df_folds['fn'].std()
    print(f"\nFALSOS NEGATIVOS (média):")
    print(f"   {fn_mean:.1f} ± {fn_std:.1f} casos")
    
    # Validação de requisitos
    recall_medio = estatisticas['recall']['media']
    f2_medio = estatisticas['f2_score']['media']
    
    print(f"\n{'='*80}")
    print("VALIDAÇÃO DE REQUISITOS CLÍNICOS")
    print('='*80)
    
    print(f"\nRecall médio: {recall_medio:.4f}")
    marca_recall = '✓ ATENDE' if recall_medio >= 0.90 else '✗ NÃO ATENDE'
    print(f"  Requisito (≥ 0.90): {marca_recall}")
    
    print(f"\nF2-Score médio: {f2_medio:.4f}")
    marca_f2 = '✓ ATINGE' if f2_medio >= 0.85 else '✗ NÃO ATINGE'
    print(f"  Meta (≥ 0.85): {marca_f2}")
    
    print('='*80)
    
    return df_folds, estatisticas


# ============================================================================
# FUNÇÃO 4: OTIMIZAÇÃO DE THRESHOLD
# ============================================================================

def otimizar_threshold(modelo, X_test, y_test, criterio='f2', 
                       plot=True, save_path=None):
    """
    Otimização sistemática de threshold de decisão.
    Testa 90 valores entre 0.1 e 0.9 para encontrar threshold ótimo.
    
    Parameters:
    -----------
    modelo : sklearn model treinado
        Modelo com método predict_proba
    X_test, y_test : array-like
        Dados de teste
    criterio : str
        Métrica para otimização ('f2', 'recall', 'f1')
    plot : bool
        Se True, gera visualizações
    save_path : str, optional
        Caminho para salvar visualização
        
    Returns:
    --------
    tuple
        (threshold_otimo, DataFrame com análise de todos thresholds)
    """
    # Obter probabilidades
    y_proba = modelo.predict_proba(X_test)[:, 1]
    
    # Testar thresholds
    thresholds = np.arange(0.10, 0.95, 0.01)
    resultados = []
    
    print("="*80)
    print("OTIMIZAÇÃO DE THRESHOLD DE DECISÃO")
    print("="*80)
    print(f"\nCritério de otimização: {criterio.upper()}")
    print(f"Testando {len(thresholds)} thresholds (0.10 a 0.94)...\n")
    
    for thresh in thresholds:
        y_pred_thresh = (y_proba >= thresh).astype(int)
        
        # Evitar divisão por zero
        if len(np.unique(y_pred_thresh)) < 2:
            continue
        
        tn, fp, fn, tp = confusion_matrix(y_test, y_pred_thresh).ravel()
        
        recall = recall_score(y_test, y_pred_thresh)
        precision = precision_score(y_test, y_pred_thresh, zero_division=0)
        f1 = f1_score(y_test, y_pred_thresh, zero_division=0)
        f2 = fbeta_score(y_test, y_pred_thresh, beta=2, zero_division=0)
        specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
        
        resultados.append({
            'threshold': thresh,
            'recall': recall,
            'precision': precision,
            'f1_score': f1,
            'f2_score': f2,
            'specificity': specificity,
            'fn': fn,
            'fp': fp,
            'tp': tp,
            'tn': tn
        })
    
    df_thresholds = pd.DataFrame(resultados)
    
    # Identificar threshold ótimo
    if criterio == 'f2':
        idx_otimo = df_thresholds['f2_score'].idxmax()
    elif criterio == 'recall':
        idx_otimo = df_thresholds['recall'].idxmax()
    elif criterio == 'f1':
        idx_otimo = df_thresholds['f1_score'].idxmax()
    else:
        raise ValueError(f"Critério '{criterio}' não reconhecido")
    
    resultado_otimo = df_thresholds.loc[idx_otimo]
    
    # Resultado com threshold padrão 0.50
    resultado_05 = df_thresholds.iloc[(df_thresholds['threshold'] - 0.50).abs().argsort()[:1]]
    resultado_05 = resultado_05.iloc[0]
    
    # Imprimir comparação
    print(f"{'='*80}")
    print("COMPARAÇÃO: THRESHOLD PADRÃO vs OTIMIZADO")
    print('='*80)
    
    print(f"\n📊 Threshold PADRÃO (0.50):")
    print(f"   Recall:        {resultado_05['recall']:.4f}")
    print(f"   F2-Score:      {resultado_05['f2_score']:.4f}")
    print(f"   Precisão:      {resultado_05['precision']:.4f}")
    print(f"   Especificidad: {resultado_05['specificity']:.4f}")
    print(f"   FN:            {int(resultado_05['fn'])}")
    print(f"   FP:            {int(resultado_05['fp'])}")
    
    print(f"\n🎯 Threshold OTIMIZADO ({resultado_otimo['threshold']:.3f}):")
    print(f"   Recall:        {resultado_otimo['recall']:.4f}")
    print(f"   F2-Score:      {resultado_otimo['f2_score']:.4f}")
    print(f"   Precisão:      {resultado_otimo['precision']:.4f}")
    print(f"   Especificidad: {resultado_otimo['specificity']:.4f}")
    print(f"   FN:            {int(resultado_otimo['fn'])}")
    print(f"   FP:            {int(resultado_otimo['fp'])}")
    
    print(f"\n📈 GANHOS COM OTIMIZAÇÃO:")
    ganho_recall = (resultado_otimo['recall'] - resultado_05['recall']) * 100
    ganho_f2 = (resultado_otimo['f2_score'] - resultado_05['f2_score']) * 100
    reducao_fn = int(resultado_05['fn'] - resultado_otimo['fn'])
    
    print(f"   Recall:        {ganho_recall:+.2f} pontos percentuais")
    print(f"   F2-Score:      {ganho_f2:+.2f} pontos percentuais")
    print(f"   Redução FN:    {reducao_fn:+d} casos")
    print(f"   Aumento FP:    {int(resultado_otimo['fp'] - resultado_05['fp']):+d} casos")
    
    print('='*80)
    
    if plot:
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        
        # Plot 1: Recall e Especificidade vs Threshold
        ax1 = axes[0, 0]
        ax1.plot(df_thresholds['threshold'], df_thresholds['recall'], 
                label='Recall (Sensibilidade)', linewidth=2.5, color='#2196F3')
        ax1.plot(df_thresholds['threshold'], df_thresholds['specificity'], 
                label='Especificidade', linewidth=2.5, color='#4CAF50')
        ax1.axvline(resultado_otimo['threshold'], color='red', linestyle='--',
                   linewidth=2, label=f'Ótimo ({resultado_otimo["threshold"]:.3f})')
        ax1.axvline(0.5, color='gray', linestyle=':', alpha=0.7, linewidth=2,
                   label='Padrão (0.50)')
        ax1.axhline(0.90, color='red', linestyle=':', alpha=0.5, linewidth=1.5,
                   label='Meta Recall (0.90)')
        ax1.set_xlabel('Threshold', fontsize=12, fontweight='bold')
        ax1.set_ylabel('Score', fontsize=12, fontweight='bold')
        ax1.set_title('Recall e Especificidade vs Threshold', 
                     fontsize=14, fontweight='bold')
        ax1.legend(loc='best', fontsize=10)
        ax1.grid(alpha=0.3, linestyle='--')
        ax1.set_ylim([0, 1.05])
        
        # Plot 2: F1 e F2-Score vs Threshold
        ax2 = axes[0, 1]
        ax2.plot(df_thresholds['threshold'], df_thresholds['f1_score'], 
                label='F1-Score', linewidth=2.5, color='#9C27B0')
        ax2.plot(df_thresholds['threshold'], df_thresholds['f2_score'], 
                label='F2-Score', linewidth=2.5, color='#FF9800')
        ax2.axvline(resultado_otimo['threshold'], color='red', linestyle='--',
                   linewidth=2)
        ax2.axvline(0.5, color='gray', linestyle=':', alpha=0.7, linewidth=2)
        ax2.axhline(0.85, color='orange', linestyle=':', alpha=0.5, linewidth=1.5,
                   label='Meta F2 (0.85)')
        ax2.set_xlabel('Threshold', fontsize=12, fontweight='bold')
        ax2.set_ylabel('Score', fontsize=12, fontweight='bold')
        ax2.set_title('F1 e F2-Score vs Threshold', 
                     fontsize=14, fontweight='bold')
        ax2.legend(loc='best', fontsize=10)
        ax2.grid(alpha=0.3, linestyle='--')
        ax2.set_ylim([0, 1.05])
        
        # Plot 3: Falsos Negativos e Positivos vs Threshold
        ax3 = axes[1, 0]
        ax3.plot(df_thresholds['threshold'], df_thresholds['fn'], 
                label='Falsos Negativos (FN)', linewidth=2.5, color='#F44336')
        ax3.plot(df_thresholds['threshold'], df_thresholds['fp'], 
                label='Falsos Positivos (FP)', linewidth=2.5, color='#FF9800')
        ax3.axvline(resultado_otimo['threshold'], color='red', linestyle='--',
                   linewidth=2)
        ax3.axvline(0.5, color='gray', linestyle=':', alpha=0.7, linewidth=2)
        ax3.set_xlabel('Threshold', fontsize=12, fontweight='bold')
        ax3.set_ylabel('Número de Erros', fontsize=12, fontweight='bold')
        ax3.set_title('Falsos Negativos e Positivos vs Threshold', 
                     fontsize=14, fontweight='bold')
        ax3.legend(loc='best', fontsize=10)
        ax3.grid(alpha=0.3, linestyle='--')
        
        # Plot 4: Trade-off Recall-Precisão
        ax4 = axes[1, 1]
        # Plotar curva
        ax4.plot(df_thresholds['recall'], df_thresholds['precision'], 
                linewidth=2.5, color='#673AB7', alpha=0.7)
        # Marcar ponto ótimo
        ax4.scatter(resultado_otimo['recall'], resultado_otimo['precision'], 
                   s=300, color='red', marker='*', zorder=5, edgecolors='darkred',
                   linewidths=2, label=f'Ótimo (thresh={resultado_otimo["threshold"]:.3f})')
        # Marcar ponto padrão
        ax4.scatter(resultado_05['recall'], resultado_05['precision'], 
                   s=200, color='gray', marker='o', zorder=5, edgecolors='black',
                   linewidths=2, label='Padrão (thresh=0.50)')
        ax4.set_xlabel('Recall (Sensibilidade)', fontsize=12, fontweight='bold')
        ax4.set_ylabel('Precisão', fontsize=12, fontweight='bold')
        ax4.set_title('Trade-off Recall-Precisão', 
                     fontsize=14, fontweight='bold')
        ax4.legend(loc='best', fontsize=10)
        ax4.grid(alpha=0.3, linestyle='--')
        ax4.set_xlim([0, 1.05])
        ax4.set_ylim([0, 1.05])
        
        plt.suptitle('Análise Completa de Otimização de Threshold - Predição de Hipertensão', 
                    fontsize=16, fontweight='bold', y=0.995)
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"\n✅ Visualização salva em: {save_path}")
        
        plt.show()
    
    return resultado_otimo['threshold'], df_thresholds


# ============================================================================
# EXEMPLO DE USO COMPLETO
# ============================================================================

if __name__ == "__main__":
    """
    Exemplo de implementação do pipeline completo.
    Substitua X e y pelos seus dados reais.
    """
    
    print("\n" + "="*80)
    print("PIPELINE COMPLETO DE TREINAMENTO - VERSÃO OTIMIZADA")
    print("="*80)
    
    # Supondo que X e y já foram carregados
    # X = seu_dataframe_features
    # y = seu_series_target
    
    # ========== ETAPA 1: TESTE DE PROPORÇÕES ==========
    print("\n\n" + "#"*80)
    print("# ETAPA 1: TESTE DE MÚLTIPLAS PROPORÇÕES")
    print("#"*80)
    
    # melhor_test_size, df_proporcoes = testar_proporcoes_treinoteste(
    #     X, y, proporcoes=[0.20, 0.25, 0.30]
    # )
    # df_proporcoes.to_csv('results/analises/teste_proporcoes.csv', index=False)
    
    # ========== ETAPA 2: DIVISÃO COM MELHOR PROPORÇÃO ==========
    print("\n\n" + "#"*80)
    print("# ETAPA 2: DIVISÃO COM SMOTE")
    print("#"*80)
    
    # X_train, X_test, y_train, y_test = train_test_split(
    #     X, y, test_size=melhor_test_size, random_state=42, stratify=y
    # )
    
    # smote = SMOTE(random_state=42)
    # X_train_balanced, y_train_balanced = smote.fit_resample(X_train, y_train)
    
    # ========== ETAPA 3: TREINAMENTO E AVALIAÇÃO ==========
    print("\n\n" + "#"*80)
    print("# ETAPA 3: TREINAMENTO DE MODELOS")
    print("#"*80)
    
    # Exemplo com Random Forest
    # modelo = RandomForestClassifier(
    #     n_estimators=200,
    #     max_depth=15,
    #     min_samples_split=10,
    #     class_weight='balanced',
    #     random_state=42,
    #     n_jobs=-1
    # )
    
    # modelo.fit(X_train_balanced, y_train_balanced)
    
    # resultados = avaliar_modelo_completo(
    #     modelo, X_train_balanced, y_train_balanced, 
    #     X_test, y_test, "Random Forest"
    # )
    
    # ========== ETAPA 4: CROSS-VALIDATION ==========
    print("\n\n" + "#"*80)
    print("# ETAPA 4: VALIDAÇÃO COM K-FOLD")
    print("#"*80)
    
    # df_cv, stats_cv = cross_validation_com_smote(
    #     modelo, X, y, n_splits=5
    # )
    # df_cv.to_csv('results/analises/cross_validation.csv', index=False)
    
    # ========== ETAPA 5: OTIMIZAÇÃO DE THRESHOLD ==========
    print("\n\n" + "#"*80)
    print("# ETAPA 5: OTIMIZAÇÃO DE THRESHOLD")
    print("#"*80)
    
    # threshold_otimo, df_thresholds = otimizar_threshold(
    #     modelo, X_test, y_test, 
    #     criterio='f2',
    #     plot=True,
    #     save_path='results/visualizacoes/otimizacao_threshold.png'
    # )
    # df_thresholds.to_csv('results/analises/analise_thresholds.csv', index=False)
    
    # ========== ETAPA 6: AVALIAÇÃO FINAL COM THRESHOLD OTIMIZADO ==========
    print("\n\n" + "#"*80)
    print("# ETAPA 6: AVALIAÇÃO FINAL")
    print("#"*80)
    
    # y_proba_final = modelo.predict_proba(X_test)[:, 1]
    # y_pred_final = (y_proba_final >= threshold_otimo).astype(int)
    
    # # Reavaliar com threshold otimizado
    # from sklearn.metrics import confusion_matrix
    # tn, fp, fn, tp = confusion_matrix(y_test, y_pred_final).ravel()
    
    # print("\n" + "="*80)
    # print("RESULTADOS FINAIS COM THRESHOLD OTIMIZADO")
    # print("="*80)
    # print(f"\nThreshold: {threshold_otimo:.3f}")
    # print(f"Recall:    {recall_score(y_test, y_pred_final):.4f}")
    # print(f"F2-Score:  {fbeta_score(y_test, y_pred_final, beta=2):.4f}")
    # print(f"FN:        {fn}")
    # print(f"FP:        {fp}")
    
    print("\n\n" + "="*80)
    print("PIPELINE COMPLETO IMPLEMENTADO!")
    print("="*80)
    print("\nPróximos passos:")
    print("1. Substituir seções relevantes no Notebook 04")
    print("2. Executar cada etapa sequencialmente")
    print("3. Salvar todos os resultados e visualizações")
    print("4. Documentar decisões no TCC")
